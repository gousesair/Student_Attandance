package com.example.gouse.student_attandance;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;



public class NotificationFile {

    private static final int ATTENDANCE_REMINDER_NOTIFICATION_ID = 1138;
    private static final int ATTENDANCE_REMINDER_PENDING_INTENT_ID = 3417;
    private static final String ATTENDANCE_REMINDER_NOTIFICATION_CHANNEL_ID = "reminder_notification_channel";
    private static final int ACTION_IGNORE_PENDING_INTENT_ID = 14;

    public static void clearAllNotifications(Context context)
    {
        NotificationManager notificationManager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();
    }

    public static void remindUserAttendance(Context context)
    {
        NotificationManager notificationManager =(NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            NotificationChannel mChannel = new NotificationChannel(
                    ATTENDANCE_REMINDER_NOTIFICATION_CHANNEL_ID,"Name",
                    NotificationManager.IMPORTANCE_HIGH);

            notificationManager.createNotificationChannel(mChannel);
        }

        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(context,ATTENDANCE_REMINDER_NOTIFICATION_CHANNEL_ID)
                        .setColor(ContextCompat.getColor(context, R.color.colorPrimary))
                        .setSmallIcon(R.drawable.stu)
                        .setLargeIcon(largeIcon(context))
                        .setContentTitle("Notification Reminder")
                        .setContentText("Don't forget to mark attendance")
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(
                                "Hello"))
                        .setDefaults(Notification.DEFAULT_VIBRATE)
                        .setContentIntent(contentIntent(context))
//                        .addAction(ignoreReminderAction(context))
                        .setAutoCancel(true);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                && Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
        {
            notificationBuilder.setPriority(NotificationCompat.PRIORITY_HIGH);
        }

        notificationManager.notify(ATTENDANCE_REMINDER_NOTIFICATION_ID,notificationBuilder.build());
    }

//    private static NotificationCompat.Action ignoreReminderAction(Context context)
//    {
//        Intent ignoreReminderIntent = new Intent(context, AttendenceIntentService.class);
//        ignoreReminderIntent.setAction(AttendanceTasks.ACTION_DISMISS_NOTIFICATION);
//        PendingIntent ignoreReminderPendingIntent = PendingIntent.getService(
//                context,
//                ACTION_IGNORE_PENDING_INTENT_ID,
//                ignoreReminderIntent,
//                PendingIntent.FLAG_UPDATE_CURRENT);
//
//        NotificationCompat.Action ignoreReminderAction = new NotificationCompat.Action(R.drawable.stu
//                "No, thanks.",
//                ignoreReminderPendingIntent);
//
//        return ignoreReminderAction;
//
//    }

    private static PendingIntent contentIntent(Context context){
        Intent startActiviyIntent = new Intent(context, MainActivity.class);

        return PendingIntent.getActivity(context,ATTENDANCE_REMINDER_PENDING_INTENT_ID,
                startActiviyIntent,PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static Bitmap largeIcon(Context context){
        Resources  res = context.getResources();
        Bitmap largeIcon = BitmapFactory.decodeResource(res, R.drawable.stu);
        return largeIcon;
    }


}