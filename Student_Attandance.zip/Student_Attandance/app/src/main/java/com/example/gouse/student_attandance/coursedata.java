package com.example.gouse.student_attandance;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class coursedata extends AsyncTask<Void,Void,Void> {
    String jdata = "";
    String parsedData = "";
    String singleParsed="";
    Double cgpa=0.0;
    Double grade;
    Integer credit;

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            URL url = new URL("http://msitis-iiith.appspot.com/api/course/ag5ifm1zaXRpcy1paWl0aHIUCxIHU3R1ZGVudBiAgICAr4aICgw");
            HttpURLConnection httpconnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpconnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line ="";
            while(line != null) {
                line = br.readLine();
                jdata = jdata + line;
            }





        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private int getname(String name) {
        switch (name)
        {
            case "Web programming":
                return 3;
            case "Mobile Programming":
                return 0;
            case "Introduction to Computer Systems":
                return 4;
            case "Cyber Security":
                return 2;
            case "Computer Network Foundation":
                return 2;
            case "DBMS":
                return 2;
            case "ADS-2":
                return 4;
            case "ADS-1":
                return 4;
            case "CSPP-2":
                return 4;
            case "CSPP-1":
                return 4;
            case "Computational Thinking":
                return 2;
            case "Digital Literacy":
                return 1;
            default:
                return 0;
        }
    }

    private double getgrade(String grade) {
        switch (grade)
        {
            case "Ex":
                return 10;
            case "A+":
                return 9.5;
            case "A":
                return 9;
            case "B+":
                return 8.5;
            case "B":
                return 8;
            case "C":
                return 7;
            default:
                return 0;
        }

    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        try
        {
            JSONObject jr=new JSONObject(jdata);
            JSONArray jarr = jr.getJSONArray("data");
            parsedData="";
            String name="1234";
            String id="zxcv";
            String grades="asd";
            String mentor="qwe";

            for (int i=0;i<jarr.length();i++) {
                JSONObject abc = jarr.getJSONObject(i);
                String as=abc.get("course_name").toString();
                if(!as.equals("Mobile Programming")) {
                    id = abc.get("course_id").toString();
                    name = abc.get("course_name").toString();
                    credit = getname(abc.get("course_name").toString());
                    grade = getgrade(abc.get("grade").toString());
                   grades = abc.get("grade").toString();
                    mentor = abc.get("mentor_name").toString();
//                    parsedData += ",";
                    courses.items.add(id+"---"+name+"---"+grades+"---"+mentor);
                    ece(credit, grade);
                }

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        this.cgpa/=36;
        courses.cdata.setText("Cgpa: "+this.cgpa.toString().substring(0,4));
//        courses.cos+=this.parsedData;



    }

    public void ece(double credit,double grade)
    {
//        courses.cos=this.parsedData;
        cgpa+=credit*grade;

    }
}
