package com.example.gouse.student_attandance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class Attandance extends AppCompatActivity {
    public static ListView w;
    public static  ArrayList<String> al= new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attandance);

        DataBase db = new DataBase(this, null, null, 1);
//        ListView w = findViewById(R.id.lv);
        db.manual();
        String att=db.loadHandler();
        String[] dat=att.split(System.getProperty("line.separator"));
        for(int i=0; i<dat.length;i++)
        {
            al.add(dat[i]);
        }
        w=(ListView) findViewById(R.id.lv);
        w.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,al));
        al=new ArrayList<>();
    }
}
