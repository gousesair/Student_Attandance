package com.example.gouse.student_attandance;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.test.mock.MockPackageManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    Button btnShowLocation;
    Handler mHandler;
    boolean flag = true;
    private static final int REQUEST_CODE_PERMISSION = 2;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;
    GPSTracker gps;
    public static Double latitude;
    public static Double longitude;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.mHandler = new Handler();

        this.mHandler.postDelayed(m_Runnable,5000);
        try {
            if (ActivityCompat.checkSelfPermission(this, mPermission)
                    != MockPackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{mPermission},
                        REQUEST_CODE_PERMISSION);

                // If any permission above not allowed by user, this condition will execute every time, else your else part will work
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);


        Button button = (Button) findViewById(R.id.Button05);
        button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, courses.class);
                startActivity(intent);
            }
        });
//        Button viewAttandance = findViewById(R.id.Button04);
//        viewAttandance.setOnClickListener();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        fData process = new fData();
        process.execute();
        int id = item.getItemId();
        if (id == R.id.profile) {
            Intent intent = new Intent(MainActivity.this, profile.class);
            startActivity(intent);
            return true;
        }
        return true;
    }

    public void load(View view)
    {
        Intent intent = new Intent(this,Attandance.class);
        startActivity(intent);

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void check(View view) {

        // create class object
        gps = new GPSTracker(MainActivity.this);

        // check if GPS enabled
        if (gps.canGetLocation()) {

            latitude = gps.getLatitude();
            longitude = gps.getLongitude();

            DataBase db = new DataBase(this, null, null, 1);
            db.langitude=latitude.toString();
            db.longitude=longitude.toString();


            // \n is for new line
            Toast.makeText(getApplicationContext(), "Your Location is - \nLat: "
                    + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
        } else {
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
        }


        DataBase db = new DataBase(this, null, null, 1);
        if (db.findHandler()) {
            db.updateHandler();
        } else {
            db.addHandler();
        }
//        TextView w = (TextView) findViewById(R.id.time);
//        w.setText(db.loadHandler());
    }

    private final Runnable m_Runnable = new Runnable()
    {
        boolean flag = true;
        public void run()

        {
//            Button button = findViewById(R.id.check_in_button);
            Calendar calendar = Calendar.getInstance();
            Date now = calendar.getTime();
            SimpleDateFormat date = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            final String currentTime = date.format(now);

//            attendanceContract.insert(1, 0.25);
//            attendanceContract.insert(2, 0.25);
//            attendanceContract.insert(3, 0.50);

            if (currentTime.compareTo("08:50:00")>0 && currentTime.compareTo("09:10:00")<0){
                if (flag && currentTime.compareTo("08:55:00")<0){
                   NotificationFile.remindUserAttendance(MainActivity.this);
                    flag = false;
                }

            }
            else if (currentTime.compareTo("10:20:00")>0 && currentTime.compareTo("11:10:00")<0){
                if (flag){
//                    postNotification();
                    NotificationFile.remindUserAttendance(MainActivity.this);
                    flag = false;
                }
//                startTimer(currentTime, "11:10:00");
            }
            else if (currentTime.compareTo("13:50:00")>0 && currentTime.compareTo("14:10:00")<0){
                if (flag){
                    NotificationFile.remindUserAttendance(MainActivity.this);
                    flag = false;
                }
//                startTimer(currentTime, "14:10:00");
            }
            else {
                flag = true;
            }




            MainActivity.this.mHandler.postDelayed(m_Runnable,5000);
        }

    };

}

