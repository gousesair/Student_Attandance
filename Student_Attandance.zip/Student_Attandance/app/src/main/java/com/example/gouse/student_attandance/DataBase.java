package com.example.gouse.student_attandance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DataBase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "studentDB.db";
    public static final String TABLE_NAME = "StudentsTable";
    public static final String DATE = "PresentDay";
//    public static final String TIME = "PresentTime";
    public static final String S1="SESSION1";
    public static final String S1_loc="SESSION1_Loction";
    public static final String S1_time="SESSION1_Time";
    public static final String S2="SESSION2";
    public static final String S2_loc="SESSION2_Loction";
    public static final String S2_time="SESSION2_Time";
    public static final String S3="SESSION3";
    public static final String S3_loc="SESSION3_Loction";
    public static final String S3_time="SESSION3_Time";
    GPSTracker gps;

    public String longitude="qwerty";
    public String langitude="asdfgh";

    Calendar c = Calendar.getInstance();
    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
    public final String formattedTime = df.format(c.getTime());
    SimpleDateFormat df1 = new SimpleDateFormat("dd/MM/yy");
    public final String formattedDate = df1.format(c.getTime());

    public DataBase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + DATE +
                " TEXT PRIMARY KEY,"+ S1 +" DOUBLE,"+S1_loc+" TEXT,"+S1_time+" TEXT,"+ S2 +" DOUBLE,"
                +S2_loc+" TEXT,"+S2_time+" TEXT,"+ S3 +" DOUBLE,"+S3_loc+" TEXT,"+S3_time+" TEXT)";
        Log.e("RECHECK",CREATE_TABLE);
//        MainActivity ma = new MainActivity();



        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public String Selectdata() {
        String result = "";
        String query = "Select * FROM " + TABLE_NAME;
//        Log.e("MARKED",query);
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String result_0 = cursor.getString(0);
//            String result_1 = cursor.getString(1);
            String result_2 = cursor.getString(1);

            String result_3 = cursor.getString(4);
            String result_4 = cursor.getString(7);
            result += result_0 + "\t\t\t\t\t\t\t\t\t\t"+ attandance(result_2) +"\t\t\t\t\t\t\t\t\t\t\t\t"+ attandance(result_3) +"\t\t\t\t\t\t\t\t\t\t"+ attandance(result_4) +
                    System.getProperty("line.separator");
//            Attandance.al.add(result);
        }
        cursor.close();
        db.close();
        return result;
    }

    private String attandance(String result) {
        switch(result)
        {
            case "0.25":
                return "A";
            case "0.5":
                return "A";
            default:
                return "P";
        }
    }

    public void manual()
    {
        ContentValues val = new ContentValues();
        String [] h = formattedDate.split("/");

        for (int i=1;i<Integer.parseInt(h[0]);i++) {
            val.put(DATE, i + "/04/18");
            val.put(S1, 0.0);
            val.put(S2, 0.0);
            val.put(S3, 0.0);
            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(TABLE_NAME, null, val);
            db.close();
        }

    }

    //    @RequiresApi(api = Build.VERSION_CODES.O)
    public void adddata() {
//
        ContentValues val = new ContentValues();
        val.put(DATE, formattedDate);


        String[] arr = formattedTime.split(":");
        if((Integer.parseInt(arr[0])==9 && Integer.parseInt(arr[1])<=10) || (Integer.parseInt(arr[0])==8 && Integer.parseInt(arr[1])>=50))
        {
//            Log.e("Longitude",MainActivity.longitude.toString());
            val.put(S1, 0.0);
            val.put(S1_loc,getloc());
            val.put(S1_time, formattedTime);
            val.put(S2, 0.25);
            val.put(S3, 0.50);
        }

        else if((Integer.parseInt(arr[0])==11 && Integer.parseInt(arr[1])<=10) || (Integer.parseInt(arr[0])==10 && Integer.parseInt(arr[1])>=50))
        {
            val.put(S1, 0.25);
            val.put(S2, 0.0);
            val.put(S2_loc,getloc());
            val.put(S2_time, formattedTime);
            val.put(S3, 0.50);
        }

        else if((Integer.parseInt(arr[0])==14 && Integer.parseInt(arr[1])<=10) || (Integer.parseInt(arr[0])==13 && Integer.parseInt(arr[1])>=50))
        {
            val.put(S1, 0.25);
            val.put(S2, 0.25);
            val.put(S3, 0.0);
            val.put(S3_loc,getloc());
            val.put(S3_time, formattedTime);
        }
        else
        {
            val.put(S1, 0.25);
            val.put(S2, 0.25);
            val.put(S3, 0.50);
        }


        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, val);
        db.close();
    }


    public boolean finddb()
    {

        String obtainedDate ="";
        String result = "";
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + DATE + " LIKE " + "'" + formattedDate + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        Log.e("MARKED",query);
        cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String result_0 = cursor.getString(0);
            if(result_0.equals(formattedDate))
            {
                return true;
            }
        }
        cursor.close();
        db.close();
        return false;

    }




//    @RequiresApi(api = Build.VERSION_CODES.O)
    public void updatedb() {
        SQLiteDatabase db = this.getWritableDatabase();

        String[] arr = formattedTime.split(":");
//        String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S1 + " = " + 0.0 + " WHERE " + DATE +" = '" + formattedDate +"'";
//        db.execSQL(updateQuery);
        if((Integer.parseInt(arr[0])==9 && Integer.parseInt(arr[1])<=10) || (Integer.parseInt(arr[0])==8 && Integer.parseInt(arr[1])>=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S1 + " = " + 0.0 + ","+S1_loc+"='"+getloc()+"',"+S1_time +"='"+formattedTime+"' WHERE " + DATE +" LIKE '" + formattedDate +"'";
            db.execSQL(updateQuery);

        }

        else if((Integer.parseInt(arr[0])==11 && Integer.parseInt(arr[1])<=10) || (Integer.parseInt(arr[0])==10 && Integer.parseInt(arr[1])>=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S2 + " = " + 0.0 + ","+S2_loc+"='"+getloc()+"',"+S2_time +"='"+formattedTime+"' WHERE " + DATE +" LIKE '" + formattedDate +"'";
            Log.e("queryyy",updateQuery);
            db.execSQL(updateQuery);

        }

        else if((Integer.parseInt(arr[0])==14 && Integer.parseInt(arr[1])<=10) || (Integer.parseInt(arr[0])==13 && Integer.parseInt(arr[1])>=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S3 + " = " + 0.0 + ","+S3_loc+"='"+getloc()+"',"+S3_time +"='"+formattedTime+"' WHERE " + DATE +" LIKE '" + formattedDate +"'";
            db.execSQL(updateQuery);
        }


    }
    public String getloc()
    {

        return "Long: "+MainActivity.longitude.toString()+" Lang: "+MainActivity.latitude.toString();
    }
}



