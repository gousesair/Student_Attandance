package com.example.gouse.student_attandance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DataBase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "studentDB.db";
    public static final String TABLE_NAME = "StudentsTable";
    public static final String DATE = "PresentDay";
    public static final String TIME = "PresentTime";
    public static final String S1="SESSION1";
    public static final String S1_loc="SESSION1_Loction";
    public static final String S2="SESSION2";
    public static final String S2_loc="SESSION2_Loction";
    public static final String S3="SESSION3";
    public static final String S3_loc="SESSION3_Loction";
    GPSTracker gps;

    public String longitude="qwerty";
    public String langitude="asdfgh";

    Calendar c = Calendar.getInstance();
    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
    public final String formattedTime = df.format(c.getTime());
    SimpleDateFormat df1 = new SimpleDateFormat("dd/MM/yy");
    public final String formattedDate = df1.format(c.getTime());

    public DataBase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + DATE +
                " TEXT PRIMARY KEY," + TIME +" TEXT,"+ S1 +" DOUBLE,"+S1_loc+" TEXT,"+ S2 +" DOUBLE,"+S2_loc+" TEXT,"+ S3 +" DOUBLE,"+S3_loc+" TEXT)";
        Log.e("RECHECK",CREATE_TABLE);
//        MainActivity ma = new MainActivity();


        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public String loadHandler() {
        String result = "";
        String query = "Select * FROM " + TABLE_NAME;
//        Log.e("MARKED",query);
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String result_0 = cursor.getString(0);
//            String result_1 = cursor.getString(1);
            String result_2 = cursor.getString(2);

            String result_3 = cursor.getString(4);
            String result_4 = cursor.getString(6);
            result += result_0 + "              "+ attandance(result_2) +"                              "+ attandance(result_3) +"                              "+ attandance(result_4) +
                    System.getProperty("line.separator");
        }
        cursor.close();
        db.close();
        return result;
    }

    private String attandance(String result) {
        switch(result)
        {
            case "0.25":
                return "A";
            case "0.5":
                return "A";
            default:
                return "P";
        }
    }

    //    @RequiresApi(api = Build.VERSION_CODES.O)
    public void addHandler() {
//
        ContentValues values = new ContentValues();
        values.put(DATE, formattedDate);
        values.put(TIME, formattedTime);

        String[] hurt = formattedTime.split(":");
        if((Integer.parseInt(hurt[0])==9 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==8 && Integer.parseInt(hurt[1])>=50))
        {
//            Log.e("Longitude",MainActivity.longitude.toString());
            values.put(S1, 0.0);
            values.put(S1_loc,getloc());
            values.put(S2, 0.25);
            values.put(S3, 0.50);
        }

        else if((Integer.parseInt(hurt[0])==11 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==10 && Integer.parseInt(hurt[1])>=50))
        {
            values.put(S1, 0.25);
            values.put(S2, 0.0);
            values.put(S2_loc,getloc());
            values.put(S3, 0.50);
        }

        else if((Integer.parseInt(hurt[0])==14 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==13 && Integer.parseInt(hurt[1])>=50))
        {
            values.put(S1, 0.25);
            values.put(S2, 0.25);
            values.put(S3, 0.0);
            values.put(S3_loc,getloc());
        }
        else
        {
            values.put(S1, 0.25);
            values.put(S2, 0.25);
            values.put(S3, 0.50);
        }


        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }


    public void maninset()
    {
        ContentValues values = new ContentValues();
        values.put(DATE, formattedDate);
        values.put(TIME, formattedTime);
    }






    public boolean findHandler(){

        String obtainedDate ="";
        String result = "";
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + DATE + " LIKE " + "'" + formattedDate + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        Log.e("MARKED",query);
        cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String result_0 = cursor.getString(0);
            if(result_0.equals(formattedDate))
            {
                return true;
            }
        }
        cursor.close();
        db.close();
        return false;

    }




//    @RequiresApi(api = Build.VERSION_CODES.O)
    public void updateHandler() {
        SQLiteDatabase db = this.getWritableDatabase();

        String[] hurt = formattedTime.split(":");
//        String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S1 + " = " + 0.0 + " WHERE " + DATE +" = '" + formattedDate +"'";
//        db.execSQL(updateQuery);
        if((Integer.parseInt(hurt[0])==9 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==8 && Integer.parseInt(hurt[1])>=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S1 + " = " + 0.0 + ","+S1_loc+"='"+getloc()+"' WHERE " + DATE +" LIKE '" + formattedDate +"'";
            db.execSQL(updateQuery);

        }

        else if((Integer.parseInt(hurt[0])==11 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==10 && Integer.parseInt(hurt[1])>=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S2 + " = " + 0.0 + ","+S2_loc+"='"+getloc()+"' WHERE " + DATE +" LIKE '" + formattedDate +"'";
            Log.e("queryyy",updateQuery);
            db.execSQL(updateQuery);

        }

        else if((Integer.parseInt(hurt[0])==14 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==13 && Integer.parseInt(hurt[1])>=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S3 + " = " + 0.0 + ","+S3_loc+"='"+getloc()+"' WHERE " + DATE +" LIKE '" + formattedDate +"'";
            db.execSQL(updateQuery);
        }


    }
    public String getloc()
    {

        return "Long: "+MainActivity.longitude.toString()+" Lang: "+MainActivity.latitude.toString();
    }
}



