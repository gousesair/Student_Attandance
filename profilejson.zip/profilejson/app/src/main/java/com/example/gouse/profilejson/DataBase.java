package com.example.gouse.profilejson;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DataBase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "studentDB.db";
    public static final String TABLE_NAME = "StudentsTable";
    public static final String DATE = "PresentDay";
    public static final String TIME = "PresentTime";
    public static final String S1="SESSION1";
    public static final String S2="SESSION2";
    public static final String S3="SESSION3";

    Calendar c = Calendar.getInstance();
    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
    public final String formattedTime = df.format(c.getTime());
    SimpleDateFormat df1 = new SimpleDateFormat("dd/MM/yy");
    public final String formattedDate = df1.format(c.getTime());

    public DataBase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + DATE +
                " TEXT PRIMARYKEY," + TIME +" TEXT,"+ S1 +" DOUBLE, "+ S2 +" DOUBLE,"+ S3 +" DOUBLE)";
        Log.e("RECHECK",CREATE_TABLE);
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public String loadHandler() {
        String result = "";
        String query = "Select * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String result_0 = cursor.getString(0);
            String result_1 = cursor.getString(1);
            String result_2 = cursor.getString(2);
            String result_3 = cursor.getString(3);
            String result_4 = cursor.getString(4);
            result += result_0 + "-" + result_1 +"-"+ result_2 +"-"+ result_3+"-"+ result_4+
                    System.getProperty("line.separator");
        }
        cursor.close();
        db.close();
        return result;
    }

//    @RequiresApi(api = Build.VERSION_CODES.O)
    public void addHandler() {
        ContentValues values = new ContentValues();
        values.put(DATE, formattedDate);
        values.put(TIME, formattedTime);

        String[] hurt = formattedTime.split(":");
        if((Integer.parseInt(hurt[0])==9 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==8 && Integer.parseInt(hurt[1])<=50))
        {
            values.put(S1, 0.0);
            values.put(S2, 0.25);
            values.put(S3, 0.50);
        }

        else if((Integer.parseInt(hurt[0])==11 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==10 && Integer.parseInt(hurt[1])<=50))
        {
            values.put(S1, 0.25);
            values.put(S2, 0.0);
            values.put(S3, 0.50);
        }

        else if((Integer.parseInt(hurt[0])==14 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==13 && Integer.parseInt(hurt[1])<=50))
        {
            values.put(S1, 0.25);
            values.put(S2, 0.25);
            values.put(S3, 0.0);
        }
        else
        {
            values.put(S1, 0.25);
            values.put(S2, 0.25);
            values.put(S3, 0.50);
        }


        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }




    public boolean findHandler(){

        String obtainedDate ="";
        String result = "";
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + DATE + " LIKE " + "'" + formattedDate + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        Log.e("MARKED",query);
        cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String result_0 = cursor.getString(0);
            if(result_0.equals(formattedDate))
            {
                return true;
            }
        }
        cursor.close();
        db.close();
        return false;

    }




//    @RequiresApi(api = Build.VERSION_CODES.O)
    public void updateHandler() {
        SQLiteDatabase db = this.getWritableDatabase();

        String[] hurt = formattedTime.split(":");
//        String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S1 + " = " + 0.0 + " WHERE " + DATE +" = '" + formattedDate +"'";
//        db.execSQL(updateQuery);
        if((Integer.parseInt(hurt[0])==9 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==8 && Integer.parseInt(hurt[1])<=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S1 + " = " + 0.0 + " WHERE " + DATE +" = '" + formattedDate +"'";
            db.execSQL(updateQuery);
        }

        else if((Integer.parseInt(hurt[0])==11 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==10 && Integer.parseInt(hurt[1])<=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S2 + " = " + 0.0 + " WHERE " + DATE +" = '" + formattedDate +"'";
            db.execSQL(updateQuery);
        }

        else if((Integer.parseInt(hurt[0])==14 && Integer.parseInt(hurt[1])<=10) || (Integer.parseInt(hurt[0])==13 && Integer.parseInt(hurt[1])<=50))
        {
            String updateQuery = "UPDATE "+TABLE_NAME +" SET " + S3 + " = " + 0.0 + " WHERE " + DATE +" = '" + formattedDate +"'";
            db.execSQL(updateQuery);
        }


    }
}



