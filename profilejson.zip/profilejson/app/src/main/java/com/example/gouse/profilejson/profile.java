package com.example.gouse.profilejson;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class profile extends AppCompatActivity {

    public static TextView fdata;
    public static TextView cdata;
//    public static String data="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
//        fdata.setText(data);
        fdata=(TextView) findViewById(R.id.fdata);
        fData process =new fData();
        process.execute();



    }


}