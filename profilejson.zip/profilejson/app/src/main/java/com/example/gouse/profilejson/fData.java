package com.example.gouse.profilejson;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class fData extends AsyncTask<Void,Void,Void> {
    String jdata = "";
    String parsedData = "";
    String singleParsed="";

    @Override
    protected Void doInBackground(Void... voids) {
        try {
//            System.out.print("qwertyuio");
            URL url = new URL("http://msitis-iiith.appspot.com/api/profile/ag5ifm1zaXRpcy1paWl0aHIUCxIHU3R1ZGVudBiAgICAr4aICgw");
//            System.out.print("zxcvbnm,");
            HttpURLConnection httpconnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpconnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line ="";
            while(line != null) {
                line = br.readLine();
                jdata = jdata + line;
            }



            JSONObject jr=new JSONObject(jdata);
            JSONArray jarr = jr.getJSONArray("data");
            JSONObject abc = jarr.getJSONObject(0);

            parsedData="Application number: "+abc.get("application_number");
            parsedData+="\n \n \n Full name: "+abc.get("student_fullname");
            parsedData+="\n \n \n Email: "+abc.get("student_email");
            parsedData+="\n \n \n Gender: "+abc.get("gender");
            parsedData+="\n \n \n Gat score: "+abc.get("total_gat_score");
            parsedData+="\n \n \n Mobile: "+abc.get("student_mobile1");
            parsedData+="\n \n \n Father: "+abc.get("father_name");
//            parsedData+="\n \n \n Mother: Ayyala Ramani";
            parsedData+="\n \n \n Roll no.: "+abc.get("roll_number");



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        profile.fdata.setText(this.parsedData);

    }

}

