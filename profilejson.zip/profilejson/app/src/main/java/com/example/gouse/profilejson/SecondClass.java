package com.example.gouse.profilejson;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

public class SecondClass extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);
    }
}
