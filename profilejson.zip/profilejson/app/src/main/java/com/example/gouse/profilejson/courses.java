package com.example.gouse.profilejson;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class courses extends AppCompatActivity{
    public static TextView cdata;
    public static String cos="";
    public static ArrayList<String> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);
        cdata=(TextView) findViewById(R.id.cor);
        coursedata process =new coursedata();
        process.execute();
        String[] ns=cos.split(",");
        System.out.println(Arrays.toString(ns));
//        ArrayList<String> items=new ArrayList<>();
        System.out.print(Arrays.toString(items.toArray()));
        ArrayAdapter<String> itemsAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);
        ListView lv=(ListView) findViewById(R.id.lv);
        lv.setAdapter(itemsAdapter);


    }
}
